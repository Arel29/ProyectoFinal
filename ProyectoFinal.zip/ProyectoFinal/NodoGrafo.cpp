#include "NodoGrafo.hpp"

NodoGrafo::NodoGrafo(const std::string& dato)
    : dato(dato)
{
}

std::string NodoGrafo::getDato() const
{
    return dato;
}

void NodoGrafo::agregarVecino(NodoGrafo *vecino, float distancia)
{
    vecinos.insertarACola(vecino);
    distancias.insertarACola(distancia);
}

ListaSimple<NodoGrafo *> &NodoGrafo::getVecinos()
{
    return vecinos;
}

ListaSimple<float> &NodoGrafo::getDistancias()
{
    return distancias;
}