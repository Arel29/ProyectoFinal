#include "Grafo.hpp"
#include <iostream>
#include <utility> // for std::pair

// Overload the << operator to print a std::pair
template <typename T1, typename T2>
std::ostream& operator<<(std::ostream& os, const std::pair<T1, T2>& p) {
    os << "(" << p.first << ", " << p.second << ")";
    return os;
}

int main() {
    Grafo grafo;

    NodoGrafo* nodoA = grafo.agregarNodo("A");
    NodoGrafo* nodoB = grafo.agregarNodo("B");
    NodoGrafo* nodoC = grafo.agregarNodo("C");
    NodoGrafo* nodoD = grafo.agregarNodo("D");

    grafo.agregarArista(nodoA, nodoB, 1.5f);
    grafo.agregarArista(nodoA, nodoC, 2.0f);
    grafo.agregarArista(nodoB, nodoD, 2.5f);
    grafo.agregarArista(nodoC, nodoD, 3.0f);

    grafo.mostrarGrafo();

    // Example of printing a pair
    std::pair<std::string, float> examplePair = {"Example", 4.5f};
    std::cout << "Example pair: " << examplePair << std::endl;

    return 0;
}
