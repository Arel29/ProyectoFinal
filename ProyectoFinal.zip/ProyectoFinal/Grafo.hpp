#pragma once

#include "NodoGrafo.hpp"
#include "ListaSimple.hpp"

class Grafo
{
public:
    Grafo();
    NodoGrafo *agregarNodo(const std::string &dato);
    void agregarArista(NodoGrafo *origen, NodoGrafo *destino, float distancia);
    void mostrarGrafo();
    void crearMatrizAdyacencia(float **matriz, int n);

private:
    ListaSimple<NodoGrafo *> nodos;
};