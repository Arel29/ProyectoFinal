#pragma once

#include "ListaSimple.hpp"
#include <string>  // for std::string

class NodoGrafo {
public:
    NodoGrafo(const std::string& dato);
    std::string getDato() const;
    void agregarVecino(NodoGrafo* vecino, float distancia);
    ListaSimple<NodoGrafo*>& getVecinos();
    ListaSimple<float>& getDistancias();

private:
    std::string dato;
    ListaSimple<NodoGrafo*> vecinos;
    ListaSimple<float> distancias;
};